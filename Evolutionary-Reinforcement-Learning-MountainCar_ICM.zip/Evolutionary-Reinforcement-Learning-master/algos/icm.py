import numpy as np
import torch
from torch import nn
from torch.nn import CrossEntropyLoss, MSELoss
from torch.distributions import Categorical, Normal
from typing import Generator
import gym.spaces as spaces
from abc import ABCMeta, abstractmethod
from collections import Counter
from tensorboardX import SummaryWriter
from sklearn.preprocessing import StandardScaler

#class Reporter(metaclass=ABCMeta):#在erl_trainer.py建立實體須去除metaclass
class Reporter:
    def __init__(self, report_interval: int = 1):
        self.counter = Counter()
        self.graph_initialized = False
        self.report_interval = report_interval
        self.t = 0
        self.writer = SummaryWriter('runs/20221007')#20221004

    def will_report(self, tag: str) -> bool:
        return self.counter[tag] % (self.report_interval + 1) == 0

    def scalar(self, tag: str, value: float):
        if self.will_report(tag):
            self._scalar(tag, value, self.counter[tag])
        self.counter[tag] += 1

    def graph(self, model, input_to_model):
        if not self.graph_initialized:
            self._graph(model, input_to_model)
            self.graph_initialized = True

    def _scalar(self, tag: str, value: float, step: int):
        self.writer.add_scalar(tag, value, step)


        
class DiscreteConverter:

    def __init__(self, space: spaces.Discrete):
        self.space = space
        self.loss = CrossEntropyLoss()

    @property
    def discrete(self) -> bool:
        return True

    @property
    def shape(self):
        return self.space.n,

    def distribution(self, logits):
        return Categorical(logits=logits)

    def reshape_as_input(self, array: np.ndarray, recurrent: bool):
        return array if recurrent else array.reshape(array.shape[0] * array.shape[1], -1)

    def action(self, tensor):
        return self.distribution(tensor).sample()

    def distance(self, policy_logits, y):
        return self.loss(policy_logits, y.long())

    def policy_out_model(self, in_features: int) -> nn.Module:
        return nn.Linear(in_features, self.shape[0])

class BoxConverter:

    def __init__(self, space: spaces.Box) -> None:
        self.space = space
        self.loss = MSELoss()

    @property
    def discrete(self) -> bool:
        return False

    @property
    def shape(self):
        return self.space.shape

    def distribution(self, logits):
        assert logits.size(1) % 2 == 0
        mid = logits.size(1) // 2
        loc = logits[:, :mid]
        scale = logits[:, mid:]
        return Normal(loc, scale)

    def reshape_as_input(self, array: np.ndarray, recurrent: bool):
        return array if recurrent else array.reshape(array.shape[0] * array.shape[1], *array.shape[2:])

    def action(self, tensor):
        min = torch.tensor(self.space.low, device=tensor.device)
        max = torch.tensor(self.space.high, device=tensor.device)
        return torch.max(torch.min(self.distribution(logits=tensor).sample(), max), min)

    def distance(self, policy_logits, y):
        return self.loss(self.action(policy_logits), y)

class ForwardModel(nn.Module):
    def __init__(self, action_converter, state_latent_features):
        super().__init__()
        self.action_converter = action_converter
        action_latent_features = 128
        if action_converter.discrete:
            self.action_encoder = nn.Embedding(action_converter.shape[0], action_latent_features)
        else:
            self.action_encoder = nn.Linear(action_converter.shape[0], action_latent_features)
        self.hidden = nn.Sequential(
            nn.Linear(action_latent_features + state_latent_features, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, state_latent_features)
        )

    def forward(self, state_latent, action):
        action = self.action_encoder(action.long() if self.action_converter.discrete else action)
        x = torch.cat((action, state_latent), dim=-1)
        x = self.hidden(x)
        return x


class InverseModel(nn.Module):
    def __init__(self, action_converter, state_latent_features):
        super().__init__()
        self.input = nn.Sequential(
            nn.Linear(state_latent_features * 2, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, 128),
            nn.ReLU(inplace=True),
            action_converter.policy_out_model(128)
        )

    def forward(self, state_latent, next_state_latent):
        return self.input(torch.cat((state_latent, next_state_latent), dim=-1))


class MlpICMModel(nn.Module):
    def __init__(self, state_converter, action_converter):
        assert len(state_converter.shape) == 1, 'Only flat spaces supported by MLP model'
        assert len(action_converter.shape) == 1, 'Only flat action spaces supported by MLP model'
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(state_converter.shape[0], 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, 128),
            nn.ReLU(inplace=True),
            nn.Linear(128, 128),

        )
        self.forward_model = ForwardModel(action_converter, 128)
        self.inverse_model = InverseModel(action_converter, 128)

    @property
    def recurrent(self) -> bool:
        return False

    def forward(self, state, next_state, action):
        state = self.encoder(state)
        next_state = self.encoder(next_state)
        next_state_hat = self.forward_model(state, action)
        action_hat = self.inverse_model(state, next_state)
        return next_state, next_state_hat, action_hat



class ICM:

    def __init__(self, state_converter, action_converter, model_factory, policy_weight, reward_scale, weight, intrinsic_reward_integration, reporter):
        self.state_converter = state_converter
        self.action_converter = action_converter
        self.device: torch.device = None
        self.dtype: torch.dtype = None
        self.model = model_factory#20221001 去掉括號!!!!!!
        self.policy_weight = policy_weight
        self.reward_scale = reward_scale
        self.weight = weight
        self.intrinsic_reward_integration = intrinsic_reward_integration
        self.reporter = reporter

    def parameters(self) -> Generator[nn.Parameter, None, None]:
        return self.model.parameters()

    def _to_tensors(self, *arrays: np.ndarray):
        return [torch.tensor(array, device=self.device, dtype=self.dtype) for array in arrays]

    def reward(self, rewards: np.ndarray, states: np.ndarray, actions: np.ndarray) -> np.ndarray:
        n, t = actions.shape[0], actions.shape[1]
        states, next_states = states[:, :-1], states[:, 1:]
        states, next_states, actions = self._to_tensors(
            self.state_converter.reshape_as_input(states, self.model.recurrent),
            self.state_converter.reshape_as_input(next_states, self.model.recurrent),
            actions.reshape(n * t, *actions.shape[2:]))
            
        next_states_latent, next_states_hat, _ = self.model(states, next_states, actions)
        intrinsic_reward = self.reward_scale / 2 * (next_states_hat - next_states_latent).norm(2, dim=-1).pow(2)
        intrinsic_reward = intrinsic_reward.cpu().detach().numpy().reshape(n, t)
        self.reporter.scalar('icm/reward', intrinsic_reward.mean().item() if self.reporter.will_report('icm/reward') else 0)
        return (1. - self.intrinsic_reward_integration) * rewards + self.intrinsic_reward_integration * intrinsic_reward

    def loss(self, policy_loss, states, next_states, actions):
        next_states_latent, next_states_hat, actions_hat = self.model(states, next_states, actions)
        forward_loss = 0.5 * (next_states_hat - next_states_latent.detach()).norm(2, dim=-1).pow(2).mean()
        inverse_loss = self.action_converter.distance(actions_hat, actions)
        curiosity_loss = self.weight * forward_loss + (1 - self.weight) * inverse_loss
        self.reporter.scalar('icm/loss', curiosity_loss.item())
        return self.policy_weight * policy_loss + curiosity_loss

    def to(self, device: torch.device, dtype: torch.dtype):
        super().to(device, dtype)
        self.model.to(device, dtype)

def trajDeal(traj):

  for i in range(len(traj)):
    if i == 0:
      states = traj[i][0]
      actions = traj[i][2].reshape(1,1)
      rewards = traj[i][3][0,:].reshape(1,1)

    else:
      s = traj[i][0]
      states = np.concatenate((states,s), axis=0)
      a = traj[i][2].reshape(1,1)
      actions = np.concatenate((actions,a), axis=1)
      r = traj[i][3][0,:].reshape(1,1)
      rewards = np.concatenate((rewards,r), axis=1)
      ns = traj[i][1]

  states = np.concatenate((states,ns), axis=0)
  states = np.expand_dims(states, axis=0)
  #print('RRRRRRRRRRRRRRRRRRR ',states[0,-3:,:])
  return rewards, states, actions

def StandardNormalizer(array):#平均值0, 標準差1
  array = array.reshape(-1,1)
  scaler = StandardScaler().fit(array)
  array_scaled = scaler.transform(array)
  return array_scaled.reshape(1,-1)




  
